"use client";

import React, { useMemo, useRef, useState, useEffect } from "react";
import Link from "next/link";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { BellNotify } from "@/components/ui/bell-notify";
import { KeyboardLink } from "@/components/ui/keyboard-button";
import { ArrowRight, Zap, Shield, Rocket } from "lucide-react";

function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    if (!mq) return;
    const onChange = () => setReduced(!!mq.matches);
    onChange();
    mq.addEventListener?.("change", onChange);
    return () => mq.removeEventListener?.("change", onChange);
  }, []);
  return reduced;
}

function PipelineChip({
  icon,
  title,
  desc,
  index,
  active,
  reducedMotion,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
  index: number;
  active: boolean;
  reducedMotion: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={active ? { opacity: 1, y: 0 } : { opacity: 0.8, y: 6 }}
      transition={{ duration: 0.5, delay: reducedMotion ? 0 : 0.12 + index * 0.08 }}
      className="relative rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm overflow-hidden p-3 flex gap-2.5 items-start shadow-lg"
    >
      <div className="w-8 h-8 rounded-xl grid place-items-center border border-cyan-400/20 bg-cyan-400/5 text-cyan-400 shadow-lg flex-shrink-0 relative z-10">
        {icon}
      </div>
      <div className="relative z-10 flex flex-col gap-0.5">
        <div className="text-xs font-extrabold tracking-widest uppercase text-white/90">{title}</div>
        <div className="text-xs leading-relaxed text-slate-300/90 max-w-[28ch]">{desc}</div>
      </div>
    </motion.div>
  );
}

export function IdeaSection() {
  const reducedMotion = usePrefersReducedMotion();
  const sectionRef = useRef<HTMLElement>(null);
  const isVisible = useInView(sectionRef, { amount: 0.4, once: false });

  const chips = useMemo(
    () => [
      { icon: <Zap className="w-4 h-4" />, title: "Idea", desc: "Drop the concept. We translate it into a build plan." },
      { icon: <Shield className="w-4 h-4" />, title: "Spec", desc: "Scope, timeline, and risks — locked in fast." },
      { icon: <Rocket className="w-4 h-4" />, title: "Ship", desc: "Production delivery with clean handoff + support." },
    ],
    []
  );

  return (
    <section
      ref={sectionRef}
      className="relative w-full overflow-hidden min-h-[820px] flex items-center justify-center py-20"
      aria-label="Got an idea section"
    >
      <div className="relative z-10 w-full max-w-6xl px-4 sm:px-8">
        <div className="relative mx-auto rounded-[28px] border border-white/10 bg-black/40 backdrop-blur-xl shadow-2xl overflow-hidden">
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 p-8 sm:p-10 lg:p-12 items-center">
            <div className="lg:col-span-6 flex flex-col items-center lg:items-start">
              <div className="relative w-full flex items-center justify-center lg:justify-start">
                <motion.div
                  initial={{ opacity: 0, scale: 0.92 }}
                  animate={isVisible ? { opacity: 1, scale: 1 } : { opacity: 0.55, scale: 0.98 }}
                  transition={{ duration: 0.6 }}
                  className="relative rounded-full p-2.5 border border-white/10 bg-white/5"
                >
                  <BellNotify
                    size={360}
                    isOn={isVisible}
                    showButton={false}
                    rotationAmplitude={isVisible ? 0.65 : 0}
                    disableToggle={true}
                  />
                </motion.div>
              </div>

              <div className="mt-8 w-full grid grid-cols-1 sm:grid-cols-3 gap-4">
                {chips.map((c, idx) => (
                  <PipelineChip
                    key={c.title}
                    icon={c.icon}
                    title={c.title}
                    desc={c.desc}
                    index={idx}
                    active={isVisible}
                    reducedMotion={reducedMotion}
                  />
                ))}
              </div>
            </div>

            <div className="lg:col-span-6">
              <AnimatePresence mode="wait">
                {isVisible && (
                  <motion.div
                    key="copy"
                    initial={{ opacity: 0, y: 18 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.65, delay: reducedMotion ? 0 : 0.12 }}
                    className="text-center lg:text-left"
                  >
                    <div className="inline-flex items-center gap-2.5 px-3 py-2 rounded-full border border-white/10 bg-white/5 text-slate-200 mb-5">
                      <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-lg shadow-cyan-400/25 animate-pulse" />
                      <span className="text-xs font-extrabold tracking-widest uppercase">Rapid Delivery Mode</span>
                      <span className="opacity-50">•</span>
                      <span className="font-mono text-xs text-slate-400">idea → production</span>
                    </div>

                    <h2 className="text-4xl md:text-6xl font-extrabold tracking-tight text-white">
                      Got an <span className="text-cyan-400">Idea</span>?
                    </h2>

                    <p className="mt-4 text-slate-300 text-lg md:text-xl leading-relaxed max-w-xl mx-auto lg:mx-0">
                      If you can describe it, we can build it. Swarp turns raw concepts into production-ready software —
                      fast, clean, and engineered for scale.
                    </p>

                    <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl mx-auto lg:mx-0">
                      {[
                        { k: "Scope in 24–48h", v: "We define deliverables, timeline, and risk boundaries." },
                        { k: "Fast iterations", v: "Tight loops. Visible progress. No long silence." },
                        { k: "Production quality", v: "Clean architecture, tests, and deployment readiness." },
                        { k: "Developer-friendly", v: "Docs, handoff, and long-term maintainability." },
                      ].map((b) => (
                        <div key={b.k} className="rounded-2xl border border-white/10 bg-white/5 p-3">
                          <div className="text-xs font-extrabold text-white/90 tracking-wide">{b.k}</div>
                          <div className="mt-1 text-xs leading-relaxed text-slate-400">{b.v}</div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-8 flex flex-col sm:flex-row items-center gap-3 justify-center lg:justify-start">
                      <KeyboardLink
                        href="/services"
                        variant="primary"
                        size="lg"
                        icon={<ArrowRight className="w-5 h-5" />}
                      >
                        Explore Services
                      </KeyboardLink>

                      <Link
                        href="/contact"
                        className="inline-flex items-center gap-2 px-3 py-2.5 rounded-xl border border-white/10 bg-white/5 text-slate-300 hover:text-white hover:border-cyan-400/30 transition-colors"
                      >
                        Or send a message →
                      </Link>
                    </div>

                    <div className="mt-6 text-xs text-slate-500">
                      <span className="font-mono text-slate-400 mr-1.5">pro tip:</span>
                      include goals + constraints + deadline for a faster spec.
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default IdeaSection;
