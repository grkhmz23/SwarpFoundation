"use client";

import { motion } from "framer-motion";
import { Calendar, ArrowRight } from "lucide-react";
import { KeyboardLink } from "@/components/ui/keyboard-button";

interface Service {
  id: string;
  title: string;
  short: string;
  desc: string;
  timeline: string;
  tags: string[];
}

const SERVICES: Service[] = [
  {
    id: "web-mobile",
    title: "Web Platforms & Mobile Apps",
    short: "High-scale web & native apps",
    desc: "Product-grade UI/UX with scalable backends. Store-ready mobile builds using React Native or Flutter.",
    timeline: "8-12 Weeks",
    tags: ["React", "Next.js", "Flutter", "iOS", "Android"],
  },
  {
    id: "software-tools",
    title: "Software & Tools",
    short: "CLI, Desktop & DevTools",
    desc: "Developer-first tooling, cross-platform desktop apps (Electron/Rust), and robust CLI utilities.",
    timeline: "6-10 Weeks",
    tags: ["Rust", "Go", "Electron", "CLI"],
  },
  {
    id: "ai-systems",
    title: "AI & Chat Interfaces",
    short: "LLM integration & RAG",
    desc: "Custom RAG pipelines, fine-tuned models, and conversational UI for Support, Sales, or Ops.",
    timeline: "4-8 Weeks",
    tags: ["OpenAI", "LangChain", "Vector DB", "RAG"],
  },
  {
    id: "blockchain",
    title: "Blockchain & Web3",
    short: "DeFi, NFTs & On-chain",
    desc: "Secure smart contracts, dApps, and on-chain telemetry dashboards for DeFi and DAOs.",
    timeline: "10-14 Weeks",
    tags: ["Solana", "Ethereum", "Rust", "Anchor"],
  },
  {
    id: "security",
    title: "Security & Audit",
    short: "Pen-testing & Compliance",
    desc: "Comprehensive security audits, vulnerability assessments, and automated monitoring setups.",
    timeline: "2-4 Weeks",
    tags: ["OWASP", "Penetration", "Audit"],
  },
  {
    id: "hardware",
    title: "Hardware & Devices",
    short: "Custom builds on demand",
    desc: "We design and prototype custom computing hardware, enclosures, and IoT devices.",
    timeline: "12-24 Weeks",
    tags: ["PCB", "Firmware", "IoT", "CAD"],
  },
  {
    id: "cloud",
    title: "Cloud & DevOps",
    short: "AWS/GCP & K8s Infra",
    desc: "Scalable infrastructure as code. Kubernetes clusters, CI/CD pipelines, and cost optimization.",
    timeline: "4-8 Weeks",
    tags: ["AWS", "GCP", "Terraform", "K8s"],
  },
  {
    id: "integrations",
    title: "Integrations & APIs",
    short: "Middleware & connectors",
    desc: "Robust API development and third-party integrations (Stripe, Salesforce, Twilio).",
    timeline: "3-6 Weeks",
    tags: ["REST", "GraphQL", "Webhooks"],
  },
  {
    id: "data",
    title: "Data & Analytics",
    short: "Pipelines & BI",
    desc: "Modern data stack implementation. ETL pipelines, warehouses, and dashboards.",
    timeline: "6-10 Weeks",
    tags: ["Snowflake", "BigQuery", "ETL"],
  },
  {
    id: "design",
    title: "UI/UX & Design Systems",
    short: "Figma & tokens",
    desc: "Complete design systems, component libraries, and accessible UI kits.",
    timeline: "4-8 Weeks",
    tags: ["Figma", "Storybook", "WCAG"],
  },
];

function ServiceCard({ service, index }: { service: Service; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 + index * 0.05 }}
      className="group relative rounded-2xl border border-white/10 bg-black/40 backdrop-blur-xl p-6 hover:border-cyan-500/30 transition-all duration-300"
    >
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-cyan-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
      
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors">
            {service.title}
          </h3>
          <span className="text-xs font-mono text-cyan-400/70 bg-cyan-500/10 px-2 py-1 rounded">
            {service.timeline}
          </span>
        </div>
        
        <p className="text-sm text-slate-400 mb-4 leading-relaxed">
          {service.desc}
        </p>
        
        <div className="flex flex-wrap gap-2">
          {service.tags.map((tag) => (
            <span
              key={tag}
              className="text-[10px] font-semibold uppercase tracking-wider px-2 py-1 rounded bg-white/5 text-slate-500 border border-white/5"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

export default function ServicesPage() {
  return (
    <div className="min-h-screen pt-28 pb-20">
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-8">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/30 mb-4"
          >
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider">Service Catalog</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-bold mb-4"
          >
            <span className="text-white">Our </span>
            <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">Services</span>
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-slate-400 max-w-2xl mx-auto text-lg"
          >
            Full-stack software development from concept to production. We build web platforms, AI systems, blockchain infrastructure, and everything in between.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 gap-4 mb-12">
          {SERVICES.map((service, i) => (
            <ServiceCard key={service.id} service={service} index={i} />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-center"
        >
          <div className="inline-flex flex-col sm:flex-row items-center gap-4">
            <KeyboardLink
              href="/contact"
              variant="primary"
              size="lg"
              icon={<Calendar className="w-4 h-4" />}
            >
              Book Consultation
            </KeyboardLink>
            
            <KeyboardLink
              href="/works"
              variant="ghost"
              size="lg"
              icon={<ArrowRight className="w-4 h-4" />}
            >
              View Our Work
            </KeyboardLink>
          </div>
          
          <p className="text-sm text-slate-500 mt-6">
            Not sure what you need? We offer free 30-minute discovery calls.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
